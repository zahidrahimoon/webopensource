"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { contributorsData } from "@/data/contributors"

interface ContributorStats {
  login: string
  avatar_url: string
  html_url: string
  public_repos: number
  followers: number
}

const ContributorGrid = () => {
  const [contributorStats, setContributorStats] = useState<ContributorStats[]>([])

  useEffect(() => {
    const fetchContributorStats = async () => {
      const stats = await Promise.all(
        contributorsData.map(async (contributor) => {
          const response = await fetch(`https://api.github.com/users/${contributor.github}`)
          return response.json()
        }),
      )
      setContributorStats(stats)
    }

    fetchContributorStats()
  }, [])

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {contributorStats.map((contributor, index) => (
        <div key={contributor.login} className="flex flex-col items-center">
          <Image
            src={contributor.avatar_url || "/placeholder.svg"}
            alt={contributor.login}
            width={100}
            height={100}
            className="rounded-full mb-2"
          />
          <h3 className="font-semibold text-center">{contributorsData[index].name}</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 text-center">{contributorsData[index].role}</p>
          <div className="mt-2 flex space-x-4">
            <span className="text-sm">{contributor.public_repos} repos</span>
            <span className="text-sm">{contributor.followers} followers</span>
          </div>
        </div>
      ))}
    </div>
  )
}

export default ContributorGrid

