"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Loader2, Star } from "lucide-react"
import { toast } from "sonner"

const GitHubStarButton = ({ repo }: { repo: string }) => {
  const [starred, setStarred] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleStar = async () => {
    if (!process.env.NEXT_PUBLIC_GITHUB_TOKEN) {
      toast.error("GitHub token is not configured")
      return
    }

    setLoading(true)
    try {
      const response = await fetch(`https://api.github.com/user/starred/${repo}`, {
        method: "PUT",
        headers: {
          Authorization: `token ${process.env.NEXT_PUBLIC_GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      })

      if (response.status === 204) {
        setStarred(true)
        toast.success("Repository starred successfully!")
      } else {
        throw new Error("Failed to star repository")
      }
    } catch (error) {
      console.error("Error starring repository:", error)
      toast.error("Failed to star repository. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Button onClick={handleStar} disabled={starred || loading} className="flex items-center gap-2">
      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Star className="h-4 w-4" />}
      {starred ? "Starred" : "Star on GitHub"}
    </Button>
  )
}

export default GitHubStarButton

