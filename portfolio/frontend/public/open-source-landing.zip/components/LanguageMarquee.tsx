"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

const languages = [
  "JavaScript",
  "Python",
  "Java",
  "C++",
  "Ruby",
  "Go",
  "Rust",
  "TypeScript",
  "PHP",
  "Swift",
  "Kotlin",
  "Scala",
  "Haskell",
  "Lua",
  "Dart",
  "Elixir",
]

const LanguageMarquee = () => {
  const [githubData, setGithubData] = useState<string[]>([])

  useEffect(() => {
    fetch("https://api.github.com/languages")
      .then((response) => response.json())
      .then((data) => {
        setGithubData(Object.keys(data))
      })
      .catch((error) => console.error("Error fetching GitHub languages:", error))
  }, [])

  const allLanguages = [...new Set([...languages, ...githubData])]

  return (
    <div className="bg-gray-100 dark:bg-gray-800 py-8 overflow-hidden">
      <motion.div
        className="flex whitespace-nowrap"
        animate={{ x: ["0%", "-50%"] }}
        transition={{ ease: "linear", duration: 20, repeat: Number.POSITIVE_INFINITY }}
      >
        {allLanguages.map((lang, index) => (
          <span key={index} className="mx-4 text-lg font-semibold">
            {lang}
          </span>
        ))}
      </motion.div>
    </div>
  )
}

export default LanguageMarquee

