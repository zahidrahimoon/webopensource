"use client"

import { useState, useEffect } from "react"
import ProjectCard from "./ProjectCard"
import ProjectListSkeleton from "./ProjectListSkeleton"
import { Button } from "./ui/button"
import { projectsData } from "@/data/projects"

const PROJECTS_PER_PAGE = 10

const ProjectList = () => {
  const [currentPage, setCurrentPage] = useState(1)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate loading delay
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1500)

    return () => clearTimeout(timer)
  }, [])

  const indexOfLastProject = currentPage * PROJECTS_PER_PAGE
  const indexOfFirstProject = indexOfLastProject - PROJECTS_PER_PAGE
  const currentProjects = projectsData.slice(indexOfFirstProject, indexOfLastProject)

  const totalPages = Math.ceil(projectsData.length / PROJECTS_PER_PAGE)

  if (loading) {
    return <ProjectListSkeleton />
  }

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {currentProjects.map((project) => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>
      <div className="flex justify-center space-x-2">
        <Button onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))} disabled={currentPage === 1}>
          Previous
        </Button>
        <Button
          onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
          disabled={currentPage === totalPages}
        >
          Next
        </Button>
      </div>
    </div>
  )
}

export default ProjectList

