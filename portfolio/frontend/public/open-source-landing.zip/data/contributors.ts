export const contributorsData = [
  {
    id: 1,
    name: "Alice Johnson",
    role: "Frontend Developer",
    github: "alice-dev",
  },
  {
    id: 2,
    name: "Bob Smith",
    role: "Backend Developer",
    github: "bobsmith-code",
  },
  {
    id: 3,
    name: "Charlie Brown",
    role: "UI/UX Designer",
    github: "charliebrown-ux",
  },
  // Add more contributors...
]

