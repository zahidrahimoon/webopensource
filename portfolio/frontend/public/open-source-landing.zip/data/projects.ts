export const projectsData = [
  {
    id: 1,
    name: "Project Alpha",
    description: "A revolutionary open-source project management tool.",
    image: "/placeholder.svg?height=300&width=400",
    technologies: ["React", "Node.js", "MongoDB", "GraphQL", "TypeScript"],
    githubUrl: "https://github.com/example/project-alpha",
  },
  {
    id: 2,
    name: "Beta Framework",
    description: "Lightweight and fast web framework for modern applications.",
    image: "/placeholder.svg?height=300&width=400",
    technologies: ["Go", "WebAssembly", "Docker", "Kubernetes", "gRPC"],
    githubUrl: "https://github.com/example/beta-framework",
  },
  // Add more projects here...
]

